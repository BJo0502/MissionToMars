# Import dependencies
import splinter
from splinter import Browser
from bs4 import BeautifulSoup as soup
import pandas as pd
import requests
import datetime as dt
from webdriver_manager.chrome import ChromeDriverManager

# Set the executable path and initialize Splinter
executable_path = {'executable_path': ChromeDriverManager().install()}
browser = Browser('chrome', **executable_path, headless=False)

def mars_news(browser):
    url = 'https://redplanetscience.com/'
    browser.visit(url)
    browser.is_element_present_by_css('div.list_text', wait_time=1)
    html = browser.html
    news_soup = soup(html, 'html.parser')
    try:
        slide_elem = news_soup.select_one('div.list_text')
        news_title = slide_elem.find('div', class_='content_title').get_text()
        news_para = slide_elem.find('div', class_='article_teaser_body').get_text()
        browser.is_element_present_by_css('div.list_image', wait_time=1)
        img_elem = news_soup.select_one('div.list_image')
        news_img_url = img_elem.find('img')['src']
    except AttributeError:
        return None, None
    return news_title, news_para, news_img_url

def featured_image(browser):
    url = 'https://spaceimages-mars.com'
    browser.visit(url)
    full_image_elem = browser.find_by_tag('button')[1]
    full_image_elem.click()
    html = browser.html
    img_soup = soup(html, 'html.parser')
    try:
        img_url_rel = img_soup.find('img', class_='fancybox-image').get('src')
    except AttributeError:
        return None
    jpl_img_url = f'https://spaceimages-mars.com/{img_url_rel}'
    return jpl_img_url

def mars_facts():
    try:
        df = pd.read_html('https://galaxyfacts-mars.com')[0]
    except BaseException:
        return None
    df.columns=['Description', 'Mars', 'Earth']
    df.set_index('Description', inplace=True)
    return df.to_html(classes="table table-striped")

def hemisphere_data(browser):
    # High-Resolution Mars’ Hemisphere Images and Titles
    url_main = 'https://marshemispheres.com/'
    browser.visit(url_main)
    page_main = requests.get(url_main)
    soup_main = soup(page_main.content, "html.parser")
    descriptions = soup_main.find_all('div', class_='description')
    items = soup_main.find_all('div', class_='item')
    hemisphere_image_urls=[]
    titles =[]
    img_urls_4 =[]

    for item in items:
        hemispheres = {}
        try:
            title = item.find('h3').text.replace('Enhanced','').strip()
            titles.append(title)
            img_url_1 = item.find('img', class_='thumb')['src']
            img_url_2 = img_url_1.split('.')[0]
            img_url_3 = img_url_2[40:]
            img_url_4 = f'https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/{img_url_3}.tif/full.jpg'
            img_urls_4.append(img_url_4)
            hemispheres["img_url"] = img_url_4
            hemispheres["title"] = title
            hemisphere_image_urls.append(hemispheres)
        except AttributeError as e:
            print(e)
            return None
    return hemisphere_image_urls

def scrape_all():
    news_title, news_para, news_img_url = mars_news(browser)
    mars_nasa_dict = {"news_title": news_title,
                  "news_paragraph": news_para,
                  "news_img": news_img_url,
                 "featured_image": featured_image(browser),
                 "facts": mars_facts(),
                 "last_modified": dt.datetime.now(),
                 "hemisphere_dictionary": hemisphere_data(browser)}
    return mars_nasa_dict
mars_nasa = scrape_all()
print(mars_nasa)