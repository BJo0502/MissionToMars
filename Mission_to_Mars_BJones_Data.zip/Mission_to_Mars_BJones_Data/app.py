from flask import Flask, render_template, redirect, url_for
from flask import render_template
from flask import render_template_string
from flask_pymongo import PyMongo
import Mission_2_Mars_Scrape_BJones

app = Flask(__name__, template_folder="templates")

# Use flask_pymongo to set up mongo connection
app.config["MONGO_URI"] = "mongodb://localhost:27017/mars_app"
mongo = PyMongo(app)

@app.route("/")
def index():
   mars = mongo.db.mars.find_one()
   return render_template("challenge_BJones.html", mars=mars)

@app.route("/scrape")
def scrape():
   mars = mongo.db.mars
   mars_data = Mission_2_Mars_Scrape_BJones.scrape_all()
   mars.update({}, mars_data, upsert=True)
   return redirect('/', code=302)

if __name__ == "__main__":
   app.run()


